# 减少 render 次数

1. 也就是减少diff的计算
2. 组件渲染，保证有唯一的key值

# 还有一个是减少计算的量

1. memo
2. useCallback
3. useMemo
4. PureComponent

