# schedule 调度阶段

### scheduler

1. 小顶堆 数据结构

# render 协调阶段

### reconciler

1. fiber
2. dfs
3. update

# commit 渲染阶段

### renderer

1. ReactDom
2. ReactNative
3. ReactArt